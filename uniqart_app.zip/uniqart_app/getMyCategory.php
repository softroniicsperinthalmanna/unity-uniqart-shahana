<?php 

    include'connect.php';
	$sellerID = $_POST['log_id'];
	// $res1=$con->query("SELECT COUNT(*) AS usercount FROM user_tb");
	// if($res1){
	// 	// $userCount=mysqli_num_rows($res1);
	// 	$data=mysqli_fetch_assoc($res1);

	// }
	
	$result=$con->query("SELECT COUNT(DISTINCT pdt_Category) as catCount from pdtCategory_tb where vendor_id='$sellerID'");
    if($result){
        $data = mysqli_fetch_assoc( $result );
    }
	//$list = array();
if($data!=0){
	//$list['pdt_Category'] = $rowdata['pdt_Category'];
	//$list['categoryNmbr'] = $data['catCount'];
	$catCount=$data;
}
else
$catCount=0;

//$list['categoryNmbr'] = 0;


	// $art = $con->query("SELECT DISTINCT pdt_Category FROM pdtCategory_tb where seller_id='$sellerID'");
// 	$list = array();
// if($art->num_rows>0){
// 	while ($rowdata= $art->fetch_assoc()) {
// 		$list['pdt_Category'] = $rowdata['pdt_Category'];
// 		$list['categoryNmbr'] = $catCount['catCount'];

// 		//$list['result']='success';
// 	}

// }
// else $list[]='failed';

	//echo json_encode($list);
	echo json_encode($catCount);
	?>