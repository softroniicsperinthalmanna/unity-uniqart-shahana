<?php 

	// $db = mysqli_connect('localhost','root','','userdata');
    include'connect.php';
	// if (!$con) {
	// 	echo "Database connection faild";
	// }
	$category = $_POST['category'];
	
	$art = $con->query("SELECT * FROM art_tb where type='$category'");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		$list[] = $rowdata;
		//$list['result']='success';
	}

}
else $list[]='failed';

	echo json_encode($list);
	?>