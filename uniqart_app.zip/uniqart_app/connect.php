<?php

 $con=new mysqli('localhost','root','','uniqart');
?>