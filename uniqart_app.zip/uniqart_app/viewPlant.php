<?php 

	// $db = mysqli_connect('localhost','root','','userdata');
    include'connect.php';
	// if (!$con) {
	// 	echo "Database connection faild";
	// }
	$category= $_POST['category'];
	
	$plant = $con->query("SELECT * FROM plant_tb where type='$category' ");
	$list = array();
if($plant->num_rows>0){
	while ($rowdata= $plant->fetch_assoc()) {
		$list[] = $rowdata;
		//$list['result']='success';
	}

}
else $list[]='failed';

	echo json_encode($list);
    ?>