<?php
 include 'connect.php';
$name=$_POST['name'];
$colgID = $_POST['colgID'];
$dept = $_POST['dept'];
$academicYear = $_POST['academicYear'];
$level = $_POST['level'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$userType = $_POST['userType'];


// $data=mysqli_query($con,"insert into demo_name_tb(name) values('$name')");

$sql1 = mysqli_query($con, "INSERT INTO login_tb(collegeID,password,userType) values('$colgID','$password','$userType')");
$user_id = mysqli_insert_id($con);
$sql2 = mysqli_query($con,"INSERT INTO student_tb (name,dept,academicYear,degree,email,phone,log_id) values ('$name','$dept','$academicYear','$level','$email','$phone','$user_id')");
if($sql1 && $sql2){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>