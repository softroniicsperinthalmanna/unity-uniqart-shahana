<?php
include 'connect.php';
$sellerId=$_POST['log_id'];

$bagName=$_POST['bagName'];
// $clothType = $_POST['clothType'];
$rate = $_POST['rate'];
$size = $_POST['size'];
$material = $_POST['material'];
$description = $_POST['description'];
$stock = $_POST['stock'];

$productCategory='bag';

$image = $_FILES['image']['name'];
$imagePath = 'bagUploads/'.$image;
$tmp_name = $_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name, $imagePath);



$sql1 = $con->query("INSERT INTO bag_tb(name,rate,size,material,description,noOfStock,image,vendor_id) values ('".$bagName."','".$rate."','".$size."','".$material."','".$description."','".$stock."','".$image."','".$sellerId."')");
$productID = mysqli_insert_id($con);
$sql2 = $con->query("INSERT INTO pdtCategory_tb (pdt_Id,pdt_Category,vendor_id) values ('".$productID."','".$productCategory."','".$sellerId."')");

// $sql = $con->query("INSERT INTO art_tb(name,type,rate,description) values('".$artName."','".$artType."','".$rate."','".$description."')");
if($sql1 && $sql2){
    $myarray['result']="success";

    $myarray['response']="done";
} else{
    $myarray['result']="failed";
 
}
echo json_encode($myarray);
?>