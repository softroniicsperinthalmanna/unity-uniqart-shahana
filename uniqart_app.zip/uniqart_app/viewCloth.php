<?php 

	// $db = mysqli_connect('localhost','root','','userdata');
    include'connect.php';
	// if (!$con) {
	// 	echo "Database connection faild";
	// }
	$category1 = $_POST['category1'];
	$category2 = $_POST['category2'];
	
	$art = $con->query("SELECT * FROM cloth_tb where type='$category1' or type='$category2'");
	$list = array();
if($art->num_rows>0){
	while ($rowdata= $art->fetch_assoc()) {
		$list[] = $rowdata;
		//$list['result']='success';
	}

}
else $list[]='failed';

	echo json_encode($list);
    ?>