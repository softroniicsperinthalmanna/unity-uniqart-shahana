-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2023 at 09:10 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uniqart`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tb`
--

CREATE TABLE `admin_tb` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_tb`
--

INSERT INTO `admin_tb` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `donate_pdt_tb`
--

CREATE TABLE `donate_pdt_tb` (
  `id` int(11) NOT NULL,
  `cat` varchar(100) NOT NULL,
  `sub` varchar(100) NOT NULL,
  `des` varchar(300) NOT NULL,
  `image` longblob NOT NULL,
  `donor_id` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  `size` varchar(50) NOT NULL,
  `publishyr` year(4) NOT NULL,
  `name` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donate_pdt_tb`
--

INSERT INTO `donate_pdt_tb` (`id`, `cat`, `sub`, `des`, `image`, `donor_id`, `stock`, `size`, `publishyr`, `name`, `author`) VALUES
(1, 'uniform', 'Pant', 'vfcybinbmi', 0x494d472d32303233303232352d5741303033392e6a7067, 1, 3, 'medium', 0000, '', ''),
(2, 'uniform', 'Coat', 'g cy j.u', 0x494d472d32303233303232352d5741303033372e6a7067, 1, 4, 'large', 0000, '', ''),
(3, 'uniform', 'Shirt', 'ybbunio', 0x494d472d32303233303232352d5741303033392e6a7067, 1, 1, 'XL', 0000, '', ''),
(4, 'book', '', 'crububmoni  uv h', 0x494d472d32303233303232352d5741303034312e6a7067, 1, 1, '', 1992, 'abc', 'xyz'),
(5, 'book', '', 'degdhfn', 0x494d472d32303233303232352d5741303034302e6a7067, 1, 2, '', 1980, 'dhdb', 'xbege'),
(6, 'uniform', 'Shirt', 'Cotton polyster mix', 0x313030303132373531332e6a7067, 1, 2, 'medium', 0000, '', ''),
(7, 'uniform', 'Shirt', 'Cotton polyster mix', 0x313030303132363033352e6a7067, 1, 3, 'medium', 0000, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `donor_order_tb`
--

CREATE TABLE `donor_order_tb` (
  `id` int(11) NOT NULL,
  `n_id` int(11) NOT NULL,
  `donor_id` int(11) NOT NULL,
  `dp_id` int(11) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'requested',
  `date` date NOT NULL,
  `pickdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donor_order_tb`
--

INSERT INTO `donor_order_tb` (`id`, `n_id`, `donor_id`, `dp_id`, `status`, `date`, `pickdate`) VALUES
(6, 2, 1, 2, 'requested', '2023-03-28', '2023-04-06'),
(7, 2, 1, 4, 'declined', '2023-03-28', '2023-03-31'),
(8, 1, 1, 6, 'accepted', '2023-03-31', '2023-04-06');

-- --------------------------------------------------------

--
-- Table structure for table `donor_tb`
--

CREATE TABLE `donor_tb` (
  `id` int(11) NOT NULL,
  `collegeID` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `donor_tb`
--

INSERT INTO `donor_tb` (`id`, `collegeID`, `password`) VALUES
(1, 's201', '123123');

-- --------------------------------------------------------

--
-- Table structure for table `login_tb`
--

CREATE TABLE `login_tb` (
  `log_id` int(11) NOT NULL,
  `collegeID` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `userType` varchar(50) NOT NULL,
  `service` varchar(100) NOT NULL DEFAULT 'buyer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_tb`
--

INSERT INTO `login_tb` (`log_id`, `collegeID`, `password`, `userType`, `service`) VALUES
(1, 's201', '123123', 'Student', 'buyer'),
(2, 's202', '123123', 'Student', 'buyer'),
(3, 's203', '123123', 'Student', 'buyer'),
(4, 's204', '123123', 'Student', 'buyer'),
(5, 's205', '123123', 'Student', 'buyer'),
(6, 's210', '123123', 'Student', 'buyer'),
(7, 's207', '123123', 'Student', 'buyer'),
(8, 's211', '123123', 'Student', 'buyer'),
(9, 's301', '123123', 'Student', 'buyer'),
(11, 'NT100', '123123', 'staff', 'buyer'),
(12, 'T100', '123123', 'Staff', 'buyer'),
(13, 'T102', '123123', 'Staff', 'buyer'),
(16, 's305', '909090', 'Student', 'buyer');

-- --------------------------------------------------------

--
-- Table structure for table `needy_notification_tb`
--

CREATE TABLE `needy_notification_tb` (
  `id` int(11) NOT NULL,
  `did` int(11) NOT NULL,
  `nid` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `oid` int(11) NOT NULL,
  `pickdate` date NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `needy_notification_tb`
--

INSERT INTO `needy_notification_tb` (`id`, `did`, `nid`, `pid`, `oid`, `pickdate`, `date`) VALUES
(2, 1, 2, 4, 7, '2023-03-31', '2023-03-28');

-- --------------------------------------------------------

--
-- Table structure for table `needy_tb`
--

CREATE TABLE `needy_tb` (
  `id` int(11) NOT NULL,
  `collegeID` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `needy_tb`
--

INSERT INTO `needy_tb` (`id`, `collegeID`, `password`) VALUES
(1, 's201', '123123'),
(2, 's305', '909090');

-- --------------------------------------------------------

--
-- Table structure for table `notification_tb`
--

CREATE TABLE `notification_tb` (
  `id` int(11) NOT NULL,
  `oid` int(11) NOT NULL,
  `msg_from` varchar(100) NOT NULL,
  `pid` int(11) NOT NULL,
  `pickdate` date NOT NULL,
  `vid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `tot` decimal(10,0) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification_tb`
--

INSERT INTO `notification_tb` (`id`, `oid`, `msg_from`, `pid`, `pickdate`, `vid`, `cid`, `tot`, `date`) VALUES
(1, 5, 'seller', 13, '2023-04-07', 1, 16, '800', '2023-03-28'),
(2, 4, 'seller', 12, '2023-04-03', 1, 16, '650', '2023-03-31'),
(3, 4, 'seller', 4, '2023-04-19', 1, 4, '750', '2023-04-07'),
(4, 3, 'seller', 4, '2023-04-20', 1, 4, '1250', '2023-04-07'),
(5, 1, 'seller', 2, '2023-04-19', 1, 4, '750', '2023-04-07'),
(6, 2, 'seller', 2, '2023-04-21', 1, 4, '7500', '2023-04-07'),
(7, 3, 'seller', 8, '2023-03-31', 1, 16, '100', '2023-04-07'),
(8, 2, 'seller', 10, '2023-04-04', 1, 16, '1200', '2023-04-07'),
(9, 4, 'Renter', 4, '2023-04-19', 1, 4, '750', '2023-04-08'),
(10, 1, 'Renter', 2, '2023-04-20', 1, 4, '1250', '2023-04-08');

-- --------------------------------------------------------

--
-- Table structure for table `order_tb`
--

CREATE TABLE `order_tb` (
  `id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `v_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `total_price` decimal(10,0) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'requested',
  `date` date NOT NULL DEFAULT current_timestamp(),
  `pickdate` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_tb`
--

INSERT INTO `order_tb` (`id`, `cust_id`, `v_id`, `p_id`, `total_price`, `status`, `date`, `pickdate`) VALUES
(1, 1, 1, 8, '200', 'completed', '2023-03-27', '2023-03-27'),
(2, 16, 1, 10, '1200', 'requested', '2023-03-28', '2023-04-04'),
(3, 16, 1, 8, '100', 'requested', '2023-03-28', '2023-03-31'),
(4, 16, 1, 12, '650', 'accepted', '2023-03-28', '2023-04-03'),
(5, 16, 1, 13, '800', 'accepted', '2023-03-28', '2023-04-07');

-- --------------------------------------------------------

--
-- Table structure for table `product_tb`
--

CREATE TABLE `product_tb` (
  `pdt_id` int(11) NOT NULL,
  `cat` varchar(100) NOT NULL,
  `sub` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `rate` decimal(10,0) NOT NULL,
  `des` varchar(300) NOT NULL,
  `image` longblob NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `size` varchar(100) NOT NULL,
  `material` varchar(150) NOT NULL,
  `author` varchar(150) NOT NULL,
  `publishyr` year(4) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `product_tb`
--

INSERT INTO `product_tb` (`pdt_id`, `cat`, `sub`, `name`, `rate`, `des`, `image`, `vendor_id`, `size`, `material`, `author`, `publishyr`, `stock`) VALUES
(1, 'art', 'Paintings', 'test', '500', 'sshsa xasasan c bdhdvd', 0x646f6e6174652e6a7067, 1, '', '', '', 0000, 4),
(4, 'book', 'Other', 'testbook name', '1000', 's c jdbewdwx whx', 0x73616c65312e6a7067, 1, '', '', 'abc test author', 1991, 3),
(8, 'cloth', 'Frock', 'test cloth', '3500', 'f na whf H D', 0x676f776e312e6a7067, 1, 'xxl', 'chiffon', '', 0000, 4),
(9, 'plant', 'Indoor', 'plantname', '500', 'dsfsdfv fvffsg cd', 0x646f6e617465312e6a7067, 1, 'small', '', '', 0000, 6),
(10, 'cloth', 'Frock', 'test fon cloth ', '1200', 'yxsth  ufydh  jvydyd testing data', 0x696d6167657320283231292e6a7067, 1, 'XL', 'silk', '', 0000, 3),
(12, 'book', 'Academic', 'hxhch jtesy', '650', 'xyd5dvj i', 0x494d472d32303233303232352d5741303034322e6a7067, 1, '', '', 'hcyfhvjjv lujain', 2012, 2),
(14, 'plant', 'Seed', 'ycfyi k ', '50', 'jcycji ', 0x46425f494d475f313438323939353333353938312e6a7067, 1, 'Large', '', '', 0000, 12),
(15, 'plant', 'Vegetation', 'yvyyc k ', '60', 'vycy k iv', 0x46425f494d475f313438323939353333353938312e6a7067, 1, 'Small', '', '', 0000, 15),
(16, 'cloth', 'Shirt', 'chcjjvkv', '750', 'n jcuucj ', 0x696d6167657320283537292e6a706567, 2, 'medium', ' h yxxhx', '', 0000, 2),
(17, 'cloth', 'Frock', 'Royal Blue gown', '5999', 'Net Embroidered Anarkali Long Gown Delicacy is key in this soft, flowy material which makes it a boon to strut around freely without having to worry about it weighing you down', 0x313030303134383135352e6a7067, 1, 'large', 'Chiffon', '', 0000, 1),
(18, 'cloth', 'Frock', 'Royal red gown', '7996', 'Net Embroidered Anarkali Long Gown Delicacy is key in this soft, flowy material which makes it a boon to strut around freely without having to worry about it weighing you down', 0x313030303134383135312e6a7067, 1, 'medium', 'velvet', '', 0000, 2),
(19, 'cloth', 'Frock', 'pinkish frock', '4999', 'Net Embroidered Anarkali Long Gown Delicacy is key in this soft, flowy material which makes it a boon to strut around freely without having to worry about it weighing you down', 0x313030303134383134392e6a7067, 1, 'small', 'lace', '', 0000, 1),
(20, 'cloth', 'Frock', 'Blue gown', '3999', 'Net Embroidered Anarkali Long Gown Delicacy is key in this soft, flowy material which makes it a boon to strut around freely without having to worry about it weighing you down', 0x313030303134383134372e6a7067, 1, 'XL', 'satin', '', 0000, 1),
(21, 'cloth', 'Frock', 'sky blue gown', '6780', 'Net Embroidered Anarkali Long Gown Delicacy is key in this soft, flowy material which makes it a boon to strut around freely without having to worry about it weighing you down', 0x313030303134383134352e6a7067, 1, 'medium', 'chiffon', '', 0000, 1),
(22, 'cloth', 'Shirt', 'check shirt', '540', 'This is a striped shirt with front button up look, fitting is comfortable, long sleeves, high low hem line,easy to wash , wrinkle free. ', 0x313030303134383136322e6a7067, 1, 'medium', 'cotton', '', 0000, 3),
(23, 'cloth', 'Shirt', 'Green shirt', '7999', 'This is a striped shirt with front button up look, fitting is comfortable, long sleeves, high low hem line,easy to wash , wrinkle free.', 0x313030303134383137312e6a7067, 1, 'large', 'polyster', '', 0000, 5),
(24, 'cloth', 'Shirt', 'check shirt', '880', 'This is a striped shirt with front button up look, fitting is comfortable, long sleeves, high low hem line,easy to wash , wrinkle free.', 0x313030303134383137332e6a7067, 1, 'XL', 'Denim', '', 0000, 2),
(25, 'cloth', 'Shirt', 'rose shirt', '440', 'This is a striped shirt with front button up look, fitting is comfortable, long sleeves, high low hem line,easy to wash , wrinkle free.', 0x313030303134383138372e6a7067, 1, 'small', 'satin', '', 0000, 3),
(26, 'cloth', 'Shirt', 'black shirt', '650', 'This is a striped shirt with front button up look, fitting is comfortable, long sleeves, high low hem line,easy to wash , wrinkle free.', 0x313030303134383138352e6a7067, 1, 'medium', 'poplin', '', 0000, 5),
(27, 'cloth', 'Shirt', 'lined shirt', '999', 'This is a striped shirt with front button up look, fitting is comfortable, long sleeves, high low hem line,easy to wash , wrinkle free.', 0x313030303134383138332e6a7067, 1, 'large', 'flannel', '', 0000, 1),
(28, 'cloth', 'Pants', 'white pant', '300', 'These women stylish solid pant from kotty are perfect pick for you.We offer a wide range of good quality attractive imported regular length casual pant.these straight fit pant are made with 98% polyester and 2% lycra fabric. ', 0x313030303134383230332e6a7067, 1, 'medium', 'satin', '', 0000, 3),
(29, 'cloth', 'Pants', 'fit pant', '990', 'These women stylish solid pant from kotty are perfect pick for you.We offer a wide range of good quality attractive imported regular length casual pant.these straight fit pant are made with 98% polyester and 2% lycra fabric.', 0x313030303134383230312e6a7067, 1, 'medium', 'corduroy', '', 0000, 2),
(31, 'cloth', 'Pants', 'palaaza pant', '700', 'These women stylish solid pant from kotty are perfect pick for you.We offer a wide range of good quality attractive imported regular length casual pant.these straight fit pant are made with 98% polyester and 2% lycra fabric.', 0x313030303134383139372e6a7067, 1, 'XXL', 'cotton', '', 0000, 2),
(32, 'cloth', 'Pants', 'black pants', '990', 'These women stylish solid pant from kotty are perfect pick for you.We offer a wide range of good quality attractive imported regular length casual pant.these straight fit pant are made with 98% polyester and 2% lycra fabric.', 0x313030303134383139312e6a7067, 1, 'large', 'Denim', '', 0000, 2),
(33, 'cloth', 'Pants', 'jogger pants', '990', 'These stylish solid pant from kotty are perfect pick for you.We offer a wide range of good quality attractive imported regular length casual pant.these straight fit pant are made with 98% polyester and 2% lycra fabric.', 0x313030303134383139392e6a7067, 1, 'XL', 'denim', '', 0000, 2),
(34, 'cloth', 'Top', 'check top', '499', 'check top', 0x313030303134383234322e6a7067, 1, 'medium', 'chiffon', '', 0000, 2),
(35, 'cloth', 'Top', 'navy blue top', '760', 'navy blue colored to', 0x313030303134383234302e6a7067, 1, 'medium', 'cotton', '', 0000, 3),
(36, 'cloth', 'Top', 'green top', '880', 'green top', 0x313030303134383233342e6a7067, 1, 'XL', 'satin', '', 0000, 2),
(37, 'cloth', 'Top', 'floral top', '999', 'floral type chiffon top', 0x313030303134383232362e6a7067, 1, 'large', 'chiffon', '', 0000, 5),
(38, 'cloth', 'Top', 'maxi type top', '1700', 'pink maxi type top', 0x313030303134383232342e6a7067, 1, 'XL', 'satin', '', 0000, 2),
(39, 'cloth', 'Other', 'flat top', '3300', 'flat top', 0x313030303134383232302e6a7067, 1, 'large', 'satin', '', 0000, 1),
(40, 'cloth', 'Other', 'maxi top', '1999', 'maxi type top', 0x313030303134383237332e6a7067, 1, 'large', 'satin', '', 0000, 2),
(41, 'cloth', 'Other', 'maxi top', '2200', 'brown colored maxi too', 0x313030303134383237312e6a7067, 1, 'XL', 'chiffon', '', 0000, 2),
(42, 'cloth', 'Other', 'maxi top', '3500', 'brown colored maxi top', 0x313030303134383236392e6a7067, 1, 'XL', 'chiffon', '', 0000, 2),
(43, 'cloth', 'Other', 'maxi top', '1740', 'white colored maxi top', 0x313030303134383236372e6a7067, 1, 'XL', 'chiffon', '', 0000, 2),
(44, 'cloth', 'Kurthi', 'blue salwar', '1700', 'Leeza Store Provide Decent Suit look pretty like never before. Wearing this Suit which made from Cotton Slub with Churidar Bottom and Banarasi style Dupatta. Suit has also decorative work like Thread And Beads Work along with Banarasi Jacquard Dupatta. This beautiful suit features a classy Embroider', 0x313030303134383234382e6a7067, 1, 'large', 'chiffon', '', 0000, 2),
(45, 'cloth', 'Kurthi', 'navy blue with rose churidhar', '2500', 'Leeza Store Provide Decent Suit look pretty like never before. Wearing this Suit which made from Cotton Slub with Churidar Bottom and Banarasi style Dupatta. Suit has also decorative work like Thread And Beads Work along with Banarasi Jacquard Dupatta. This beautiful suit features a classy Embroider', 0x313030303134383236322e6a7067, 1, 'large', 'chiffon', '', 0000, 2),
(46, 'cloth', 'Kurthi', 'red churidhar', '2000', 'Leeza Store Provide Decent Suit look pretty like never before. Wearing this Suit which made from Cotton Slub with Churidar Bottom and Banarasi style Dupatta. Suit has also decorative work like Thread And Beads Work along with Banarasi Jacquard Dupatta. This beautiful suit features a classy Embroider', 0x313030303134383235382e6a7067, 1, 'large', 'chiffon', '', 0000, 2),
(47, 'cloth', 'Kurthi', 'brown top', '1500', 'Leeza Store Provide Decent Suit look pretty like never before. Wearing this Suit which made from Cotton Slub with Churidar Bottom and Banarasi style Dupatta. Suit has also decorative work like Thread And Beads Work along with Banarasi Jacquard Dupatta. This beautiful suit features a classy Embroider', 0x313030303134383236302e6a7067, 1, 'large', 'chiffon', '', 0000, 2),
(48, 'cloth', 'Kurthi', 'rose churidhar', '4500', 'Leeza Store Provide Decent Suit look pretty like never before. Wearing this Suit which made from Cotton Slub with Churidar Bottom and Banarasi style Dupatta. Suit has also decorative work like Thread And Beads Work along with Banarasi Jacquard Dupatta. This beautiful suit features a classy Embroider', 0x313030303134383235362e6a7067, 1, 'large', 'chiffon', '', 0000, 3),
(49, 'cloth', 'Kurthi', 'printed salwar', '1500', 'Leeza Store Provide Decent Suit look pretty like never before. Wearing this Suit which made from Cotton Slub with Churidar Bottom and Banarasi style Dupatta. Suit has also decorative work like Thread And Beads Work along with Banarasi Jacquard Dupatta. This beautiful suit features a classy Embroider', 0x313030303134383235342e6a7067, 1, 'large', 'cotton', '', 0000, 1),
(50, 'bag', '', 'Embroidery bag', '999', 'Thread with embroided bag. Beige with brick colour bag. ', 0x313030303134383330302e6a7067, 1, 'small', 'Thread', '', 0000, 3),
(51, 'bag', '', 'Black sling bag', '469', 'Black sling leather bag. For casual use. ', 0x313030303134383239382e6a7067, 1, 'small', 'Leather', '', 0000, 3),
(52, 'bag', '', 'Mustard green leather bag', '899', 'Mustard green leather bag for casual use. ', 0x313030303134383239362e6a7067, 1, 'medium', 'Leather bag', '', 0000, 2),
(53, 'bag', '', 'Mustard yellow bag. ', '899', 'Mustard yellow sling bag for casual use. ', 0x313030303134383239342e6a7067, 1, 'medium', 'Leather', '', 0000, 4),
(54, 'bag', '', 'Printed sling bag', '999', 'Printed sling bag for casual use. ', 0x313030303134383239322e6a7067, 1, 'small', 'Cloth', '', 0000, 1),
(55, 'bag', '', 'Brick colour carry bag', '2999', 'Brick colour carry bag for travel use. ', 0x313030303134383238362e6a7067, 1, 'medium', 'Artificial leather', '', 0000, 3),
(56, 'bag', '', 'Caryy bag', '1999', 'Red colour carry bag for travel and school purpose. ', 0x313030303134383238342e6a7067, 1, 'large', 'Felt', '', 0000, 3),
(57, 'bag', '', 'Printed carry bag. ', '3999', 'Printed traveller carry bag for travelling purpose. ', 0x313030303134383238302e6a7067, 1, 'large', 'Denim', '', 0000, 3),
(58, 'bag', '', 'Sling bag', '1999', 'Red colour sling bag for casual use. ', 0x313030303134383237382e6a7067, 1, 'small', 'Leather', '', 0000, 2),
(59, 'bag', '', 'Sling bag', '699', 'Beige colour sling bag for casual use. ', 0x313030303134383237362e6a7067, 1, 'small', 'Leather', '', 0000, 3),
(60, 'book', 'Academic', 'Cambridge Academic English', '369', 'Cambridge Academic English for academic purpose. ', 0x313030303134383333302e6a7067, 1, '', '', 'Craig Thaine', 2010, 3),
(61, 'book', 'Academic', 'Textbook of Computer Science', '469', 'Computer science book for plus two students. ', 0x313030303134383332382e6a7067, 1, '', '', 'Seema Bhatnagar', 2012, 3),
(62, 'book', 'Academic', 'Computer science with python', '699', 'Python book for plus two computer science students. ', 0x313030303134383332362e6a7067, 1, '', '', 'Sumita Arora', 2013, 3),
(63, 'book', 'Academic', 'Computing with data', '699', 'Computing with data an introduction to the Data industry. ', 0x313030303134383332342e6a7067, 1, '', '', 'Guy Lebanon-Mohammed El-Geish', 2013, 3),
(64, 'book', 'Academic', 'Fundamentals of Academic writing', '699', 'Fundamentals of Academic writing for academic purpose. ', 0x313030303134383331362e6a7067, 1, '', '', 'Noushad Husain', 2014, 3),
(65, 'book', 'Academic', 'Applied Mathematics', '369', '', 0x313030303134383332302e6a7067, 1, '', '', 'Santosh R. Mitkari & Swapnal Shinde', 2017, 2);

-- --------------------------------------------------------

--
-- Table structure for table `rental_pdt_tb`
--

CREATE TABLE `rental_pdt_tb` (
  `id` int(11) NOT NULL,
  `cat` varchar(100) NOT NULL,
  `sub` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `des` varchar(300) NOT NULL,
  `image` longblob NOT NULL,
  `renter_id` int(11) NOT NULL,
  `stock` varchar(100) NOT NULL DEFAULT 'available',
  `duration` int(11) NOT NULL,
  `pay` decimal(10,0) NOT NULL,
  `size` varchar(50) NOT NULL,
  `material` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rental_pdt_tb`
--

INSERT INTO `rental_pdt_tb` (`id`, `cat`, `sub`, `name`, `des`, `image`, `renter_id`, `stock`, `duration`, `pay`, `size`, `material`) VALUES
(2, 'rentalDress', 'Lehanga', 'pink lehanga ', 'This is a pink len=hanga with a completely filled beaded works ', 0x696d6167657320283536292e6a706567, 1, 'available', 0, '2000', 'XXL', 'xhcjvkvkv'),
(3, 'jewellery', 'Ring', '', 'jcjfucjc', 0x46425f494d475f313437303331393038333939362e6a7067, 1, 'available', 0, '175', 'medium', ''),
(4, 'jewellery', 'Bracelet', '', 'yxdjcj', 0x46425f494d475f313437353439383330303635312e6a7067, 1, 'unavailable', 0, '250', 'large', '');

-- --------------------------------------------------------

--
-- Table structure for table `renter_order_tb`
--

CREATE TABLE `renter_order_tb` (
  `id` int(11) NOT NULL,
  `cust_id` int(11) NOT NULL,
  `r_id` int(11) NOT NULL,
  `rp_id` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `pay` decimal(10,0) NOT NULL,
  `status` varchar(100) NOT NULL DEFAULT 'requested',
  `date` date NOT NULL,
  `pickdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `renter_order_tb`
--

INSERT INTO `renter_order_tb` (`id`, `cust_id`, `r_id`, `rp_id`, `duration`, `pay`, `status`, `date`, `pickdate`) VALUES
(1, 4, 1, 2, 3, '7500', 'completed', '2023-04-07', '2023-04-21'),
(2, 4, 1, 2, 1, '2500', 'requested', '2023-04-07', '2023-04-11'),
(3, 4, 1, 4, 5, '1250', 'requested', '2023-04-07', '2023-04-20'),
(4, 4, 1, 4, 3, '750', 'declined', '2023-04-07', '2023-04-19');

-- --------------------------------------------------------

--
-- Table structure for table `renter_tb`
--

CREATE TABLE `renter_tb` (
  `id` int(11) NOT NULL,
  `collegeID` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `renter_tb`
--

INSERT INTO `renter_tb` (`id`, `collegeID`, `password`) VALUES
(1, 's305', '909090');

-- --------------------------------------------------------

--
-- Table structure for table `seller_tb`
--

CREATE TABLE `seller_tb` (
  `id` int(11) NOT NULL,
  `collegeID` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `seller_tb`
--

INSERT INTO `seller_tb` (`id`, `collegeID`, `password`) VALUES
(1, 's201', '123123');

-- --------------------------------------------------------

--
-- Table structure for table `staff_tb`
--

CREATE TABLE `staff_tb` (
  `staff_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `dept` varchar(100) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `staffType` varchar(100) NOT NULL,
  `log_id` int(11) NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff_tb`
--

INSERT INTO `staff_tb` (`staff_id`, `name`, `email`, `dept`, `phone`, `staffType`, `log_id`, `image`) VALUES
(1, 'Joseph', 'jj@gmail.com', 'Physics', 9082134411, 'Non-Teaching', 11, ''),
(2, 'Shan', 'shan@gmail.com', 'Computer Science', 8547565610, 'Teaching', 12, ''),
(3, 'Mehra', 'mehra@gmail.com', 'Chemistry', 9877565610, 'Teaching', 13, '');

-- --------------------------------------------------------

--
-- Table structure for table `student_tb`
--

CREATE TABLE `student_tb` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dept` varchar(50) NOT NULL,
  `academicYear` year(4) NOT NULL,
  `degree` varchar(2) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `log_id` int(11) NOT NULL,
  `image` longblob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_tb`
--

INSERT INTO `student_tb` (`id`, `name`, `dept`, `academicYear`, `degree`, `email`, `phone`, `log_id`, `image`) VALUES
(1, 'shahana', 'Physics', 2022, 'PG', 'sss@gmail.com', 9025001400, 1, ''),
(2, 'Hiba', 'Computer Science', 2022, 'UG', 'hiba@gmail.com', 9874585200, 2, ''),
(3, 'Sidrah', ' Maths', 2022, 'UG', 'sidrah@gmail.com', 7859800110, 3, ''),
(4, 'Nifa', 'Computer Science', 2022, 'UG', 'Nifa@gmail.com', 7820151024, 4, ''),
(5, 'Fida', 'Biology', 2022, 'UG', 'fida@gmail.com', 9856969610, 5, ''),
(6, 'Meera', 'Chemistry', 2022, 'UG', 'meera@gmail.com', 9810201014, 6, ''),
(7, 'Ayayna', 'Maths', 2023, 'PG', 'ayana@gmail.com', 9842562310, 7, ''),
(8, 'naina', 'Food Technology', 2023, 'UG', 'nnn@gmail.com', 9065221108, 8, ''),
(9, 'test', 'Maths', 2022, 'PG', 'test@gmail.com', 9012457880, 9, ''),
(11, 'shahma', 'Computer Science', 2022, 'UG', 'shahma123pk@gmail.com', 9072454515, 16, ''),
(12, 'shahma', 'Computer Science', 2022, 'UG', 'shahma123pk@gmail.com', 9072454515, 17, ''),
(13, 'shahma', 'Computer Science', 2022, 'UG', 'shahma123pk@gmail.com', 9072454515, 18, '');

-- --------------------------------------------------------

--
-- Table structure for table `suggestion_tb`
--

CREATE TABLE `suggestion_tb` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `msg` varchar(300) NOT NULL,
  `send_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suggestion_tb`
--

INSERT INTO `suggestion_tb` (`id`, `user_id`, `msg`, `send_date`) VALUES
(1, 1, 'abc category', '2023-01-09 00:00:00'),
(2, 1, 'Food', '2023-02-24 15:16:55'),
(3, 1, 'Food', '2023-02-24 15:16:57'),
(4, 1, 'Sandals', '2023-02-24 15:21:31'),
(5, 1, 'Sandals', '2023-02-24 15:22:46'),
(6, 2, 'dessert', '2023-02-25 14:41:13'),
(7, 2, 'Salad', '2023-02-27 15:43:52'),
(8, 1, 'xyz', '2023-03-01 07:25:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tb`
--
ALTER TABLE `admin_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donate_pdt_tb`
--
ALTER TABLE `donate_pdt_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donor_order_tb`
--
ALTER TABLE `donor_order_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `donor_tb`
--
ALTER TABLE `donor_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_tb`
--
ALTER TABLE `login_tb`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `needy_notification_tb`
--
ALTER TABLE `needy_notification_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `needy_tb`
--
ALTER TABLE `needy_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_tb`
--
ALTER TABLE `notification_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_tb`
--
ALTER TABLE `order_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_tb`
--
ALTER TABLE `product_tb`
  ADD PRIMARY KEY (`pdt_id`);

--
-- Indexes for table `rental_pdt_tb`
--
ALTER TABLE `rental_pdt_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `renter_order_tb`
--
ALTER TABLE `renter_order_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `renter_tb`
--
ALTER TABLE `renter_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `seller_tb`
--
ALTER TABLE `seller_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff_tb`
--
ALTER TABLE `staff_tb`
  ADD PRIMARY KEY (`staff_id`);

--
-- Indexes for table `student_tb`
--
ALTER TABLE `student_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suggestion_tb`
--
ALTER TABLE `suggestion_tb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tb`
--
ALTER TABLE `admin_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `donate_pdt_tb`
--
ALTER TABLE `donate_pdt_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `donor_order_tb`
--
ALTER TABLE `donor_order_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `donor_tb`
--
ALTER TABLE `donor_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login_tb`
--
ALTER TABLE `login_tb`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `needy_notification_tb`
--
ALTER TABLE `needy_notification_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `needy_tb`
--
ALTER TABLE `needy_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notification_tb`
--
ALTER TABLE `notification_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `order_tb`
--
ALTER TABLE `order_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `product_tb`
--
ALTER TABLE `product_tb`
  MODIFY `pdt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `rental_pdt_tb`
--
ALTER TABLE `rental_pdt_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `renter_order_tb`
--
ALTER TABLE `renter_order_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `renter_tb`
--
ALTER TABLE `renter_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `seller_tb`
--
ALTER TABLE `seller_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `staff_tb`
--
ALTER TABLE `staff_tb`
  MODIFY `staff_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `student_tb`
--
ALTER TABLE `student_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `suggestion_tb`
--
ALTER TABLE `suggestion_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
