-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 13, 2023 at 06:54 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uniqart`
--

-- --------------------------------------------------------

--
-- Table structure for table `art_tb`
--

CREATE TABLE `art_tb` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `rate` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `image` longblob NOT NULL,
  `vendor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `art_tb`
--

INSERT INTO `art_tb` (`id`, `name`, `type`, `rate`, `description`, `image`, `vendor_id`) VALUES
(1, 'arabic', 'Calligraphy', 800, 'The Arabic alphabet is known to be used by one of the most widely used language scripts in the world. Many scholars believe that the alphabet was created around the 4th century CE', 0x64657369676e322e6a7067, 1),
(2, 'design', 'Calligraphy', 700, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x64657369676e342e6a7067, 2),
(3, 'English', 'Calligraphy', 1200, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x656e67332e6a7067, 1),
(4, 'arabic', 'Calligraphy', 1500, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x617261626963312e6a7067, 1),
(5, 'english', 'Calligraphy', 1100, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x656e67312e6a7067, 3),
(6, 'design', 'Calligraphy', 700, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x64657369676e312e6a7067, 1),
(7, 'design', 'Calligraphy', 1100, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x64657369676e332e6a7067, 3),
(8, 'english', 'Calligraphy', 650, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x656e67322e6a7067, 3),
(9, 'Dual Box Type', 'Gift Hamper', 800, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x6261736b6574322e6a7067, 2),
(10, 'gold', 'Gift Hamper', 1250, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x676f6c642e6a7067, 2),
(11, 'blue', 'Gift Hamper', 900, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x626c75652e6a7067, 2),
(12, 'Lonely Bird ', 'Paintings', 900, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x626972642e6a7067, 3),
(13, 'Girl in a Frock', 'Paintings', 1100, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x6769726c2e6a7067, 1),
(14, 'Lavender Flower Pot', 'Paintings', 1250, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x666c6f7765722e6a7067, 1),
(15, 'Short Design', 'Mehandi', 1000, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x73342e6a7067, 3),
(16, 'Short Design 4', 'Mehandi', 1200, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x73342e6a7067, 1),
(17, 'Short Design 3', 'Mehandi', 1350, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x73332e6a7067, 1),
(18, 'Birthday', 'Save the Date', 1250, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x62646179312e6a7067, 3),
(19, 'Frame', 'Save the Date', 750, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x6672616d65322e6a7067, 3),
(20, 'Frame Pink', 'Save the Date', 850, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x6672616d65332e6a7067, 2),
(21, 'Calligraphy', 'Calligraphy', 850, 'This is an arabic design', 0x696d6167655f7069636b65723131363334323235323636363338333730302e6a7067, 1),
(22, 'Tree on edge view ', 'Paintings', 650, 'there is a full;like moon .and a tree on edge viewed very beautifully', 0x696d6167655f7069636b6572373731353131393337323832303431383932382e6a7067, 3),
(23, 'ncdskjncdsjncs', 'Paintings', 650, 'this is beautiful picture showing trees, flowers, full moon,, etc', 0x696d6167655f7069636b6572323731373435363231333930353032343135342e6a7067, 2),
(25, 'Frame Pink', 'Save the Date', 850, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', '', 1),
(26, 'Green n  grassy', 'Paintings', 850, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x6561737967726f772e6a7067, 1),
(27, 'Green n  grassy', 'Paintings', 850, 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x6561737967726f772e6a7067, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bag_tb`
--

CREATE TABLE `bag_tb` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `rate` int(11) NOT NULL,
  `size` varchar(50) NOT NULL,
  `material` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `image` longblob NOT NULL,
  `noOfStock` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bag_tb`
--

INSERT INTO `bag_tb` (`id`, `name`, `rate`, `size`, `material`, `description`, `image`, `noOfStock`, `vendor_id`) VALUES
(1, 'abc', 750, 'medium', 'jute', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x6a332e6a7067, 2, 1),
(2, 'xyz', 2500, 'large', 'PU', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x7075322e6a7067, 4, 2),
(3, 'pqr', 650, 'small', 'jute', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x6a312e6a7067, 7, 1),
(4, 'mno', 1200, 'small', 'sling', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x736c696e67322e6a7067, 5, 1),
(5, 'uvw', 850, 'small', 'box', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x626f78322e6a7067, 10, 2),
(6, 'golden put leather bags', 1200, 'large', 'PU', 'cfghv vhbhjbhbbbbbbbbbbbbbb bhbbb bbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbvvvhvhjhbhhbahxb', 0x696d6167655f7069636b6572313934313836383438373632303330343135312e6a7067, 2, 2),
(7, 'pink bag', 860, 'small', 'jute', 'bhjbj hjbjbj hjbjbjbjk kjbjjnkj bjbj', 0x696d6167655f7069636b6572313731383535333236333135363839333931332e6a7067, 2, 2),
(8, 'Leather', 850, 'medium', 'PU', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x626167342e6a7067, 5, 0),
(9, 'Leather', 850, 'medium', 'PU', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x626167342e6a7067, 5, 1),
(10, 'Leather', 850, 'medium', 'PU', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x626167342e6a7067, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `book_tb`
--

CREATE TABLE `book_tb` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `rate` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `image` longblob NOT NULL,
  `noOfStock` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_tb`
--

INSERT INTO `book_tb` (`id`, `type`, `name`, `rate`, `description`, `image`, `noOfStock`, `vendor_id`) VALUES
(1, 'academic', 'Software Engineering', 950, 'Software engineering is a systematic engineering approach to software development. A software engineer is a person who applies the principles of software engineering to design, develop, maintain, test, and evaluate computer softwar', 0x656e67696e656572312e6a7067, 2, 1),
(2, 'academic', 'Programming Fundamentals', 1200, 'This specialization develops strong programming fundamentals for learners who want to solve complex problems by writing computer programsThis specialization develops strong programming fundamentals for learners who want to solve complex problems by writing computer programs', 0x70676d66756e322e6a7067, 2, 1),
(3, 'academic', 'Discrete Mathematics', 1150, 'This specialization develops strong programming fundamentals for learners who want to solve complex problems by writing computer programsThis specialization develops strong programming fundamentals for learners who want to solve complex problems by writing computer programs', 0x64697363726574652e6a7067, 1, 1),
(4, 'other', ' Book of Night', 900, 'This specialization develops strong programming fundamentals for learners who want to solve complex problems by writing computer programsThis specialization develops strong programming fundamentals for learners who want to solve complex problems by writing computer programs', 0x626f6f6b4f664e696768742e6a7067, 1, 1),
(5, 'other', ' Magic & Miracle', 450, 'The Combat of Magic and Miracles is an enthralling journey of Deborah, filled with fantasy romance, mystical adventure and jaw-dropping twists that will keep you glued to this epic until the very last minute.', 0x6d616769634e6d697261636c652e6a7067, 2, 1),
(6, 'Other', 'History on Calligraphy', 1800, 'This Is a special edition published on 2001 based on the history of Calligraphy.The author has written and gone thru many different features and structures of calligraphy.', 0x696d6167655f7069636b6572333131313930303133353533323435383933302e6a7067, 5, 1),
(7, 'Computer Science', 'Programming fun', 650, 'bbbbbbbbbbb jhhhhhhhhhhhhhhhj   wdnsdjc hbdjhdn hebdhdbhj hbdjhd', 0x70676d66756e312e6a7067, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `cart_item_tb`
--

CREATE TABLE `cart_item_tb` (
  `cart_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `pdt_id` int(11) NOT NULL,
  `qnty` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `modified_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `cloth_tb`
--

CREATE TABLE `cloth_tb` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `rate` int(11) NOT NULL,
  `size` varchar(50) NOT NULL,
  `material` varchar(50) NOT NULL,
  `description` varchar(500) NOT NULL,
  `image` longblob NOT NULL,
  `noOfStock` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cloth_tb`
--

INSERT INTO `cloth_tb` (`id`, `name`, `type`, `rate`, `size`, `material`, `description`, `image`, `noOfStock`, `vendor_id`) VALUES
(1, 'Violet layered beautiful gown', 'Gown', 2500, 'medium', 'soft net', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x76312e6a7067, 3, 1),
(2, 'Black frock ', 'Frock', 2600, 'small', 'rayon ', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x626c616377686974652e6a7067, 2, 3),
(3, 'Pastel Pink with red floral embroidery', 'Gown', 2600, 'XXL', 'rayon ', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x70617374656c50696e6b2e6a7067, 4, 2),
(4, 'Pastel Pink with red floral embroidery', 'Gown', 2600, 'XXL', 'rayon ', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x70617374656c50696e6b2e6a7067, 4, 2),
(5, 'blue pink gown', 'blue pink gown', 2500, 'XL', 'soft net', 'casdad dasdasd dggaer fdaSawed efdsFf rDDefseF ggzdvvvvvvvvvvvvvvvvvvvvvv Sfdfsdfffffffffffffffff', 0x696d6167655f7069636b6572313833373236323237353137393838313131392e6a7067, 1, 3),
(6, 'pink frock', 'pink frock', 750, 'XL', 'rayon', 'this is a beatiful fronk in pink color ', 0x696d6167655f7069636b65723735303035373230343535303834373831312e6a7067, 2, 1),
(7, 'cotton silk', 'cotton silk', 1200, 'XL', 'silk', 'it has a bottom, top and dupatta,', 0x696d6167655f7069636b6572343131323532343439323135393532353236392e6a7067, 3, 1),
(8, 'Black frock', 'Gown', 2700, 'XL', 'Hard Crape Rayon ', 'It is the design and execution of lettering with a pen, ink brush, or other writing instrument. Contemporary calligraphic practice can be defined as \"the art of giving form to signs in an expressive, harmonious, and skillful manner\".', 0x626c61636b312e6a7067, 4, 3);

-- --------------------------------------------------------

--
-- Table structure for table `login_tb`
--

CREATE TABLE `login_tb` (
  `log_id` int(11) NOT NULL,
  `collegeID` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `userType` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login_tb`
--

INSERT INTO `login_tb` (`log_id`, `collegeID`, `password`, `userType`) VALUES
(1, 's201', '123123', 'Student'),
(2, 's202', '123123', 'Student'),
(3, 's203', '123123', 'Student'),
(4, 's204', '123123', 'Student'),
(5, 's205', '123123', 'Student'),
(6, 's210', '123123', 'Student'),
(7, 's207', '123123', 'Student'),
(8, 's211', '123123', 'Student');

-- --------------------------------------------------------

--
-- Table structure for table `order_details_tb`
--

CREATE TABLE `order_details_tb` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total` decimal(10,0) NOT NULL,
  `pickUp_date` date NOT NULL,
  `created_at` date NOT NULL,
  `modified_at` date NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `order_items_tb`
--

CREATE TABLE `order_items_tb` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `pdt_id` int(11) NOT NULL,
  `qnty` int(11) NOT NULL,
  `amt` decimal(10,0) NOT NULL,
  `created_at` date NOT NULL,
  `modified_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `payment_details_tb`
--

CREATE TABLE `payment_details_tb` (
  `pay_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amt` decimal(10,0) NOT NULL,
  `provider` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `modified_at` date NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pdtcategory_tb`
--

CREATE TABLE `pdtcategory_tb` (
  `id` int(11) NOT NULL,
  `pdt_Id` int(11) NOT NULL,
  `pdt_Category` varchar(50) NOT NULL,
  `vendor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pdtcategory_tb`
--

INSERT INTO `pdtcategory_tb` (`id`, `pdt_Id`, `pdt_Category`, `vendor_id`) VALUES
(1, 1, 'art', 1),
(2, 2, 'art', 2),
(3, 3, 'art', 1),
(4, 4, 'art', 2),
(5, 25, 'art', 1),
(6, 26, 'art', 1),
(7, 27, 'art', 1),
(8, 8, 'bag', 0),
(9, 9, 'bag', 1),
(10, 10, 'bag', 1),
(11, 7, 'book', 2),
(12, 8, 'cloth', 3);

-- --------------------------------------------------------

--
-- Table structure for table `plant_tb`
--

CREATE TABLE `plant_tb` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `rate` int(11) NOT NULL,
  `description` varchar(500) NOT NULL,
  `image` longblob NOT NULL,
  `noOfStock` int(11) NOT NULL,
  `size` varchar(50) NOT NULL,
  `vendor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `plant_tb`
--

INSERT INTO `plant_tb` (`id`, `type`, `name`, `rate`, `description`, `image`, `noOfStock`, `size`, `vendor_id`) VALUES
(1, 'indoor', 'abc', 650, 'his plant is mostly found in desert area and doesnt re', 0x66697368626f6e65204361637475732e6a7067, 3, 'small', 0),
(2, 'indoor', 'abc', 530, 'his plant is mostly found in Rajasthan and it is a flowering indoor plant area and doesnt re', 0x666c6f776572696e6720696e646f6f7220706c616e74732e6a7067, 3, 'small', 0),
(3, 'indoor', 'ZebraCactus', 530, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x7a656272614361637475732e6a7067, 3, 'small', 0),
(4, 'indoor', 'Moon Cactus', 750, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x47796d6e6f63616c796369756d206d6f6f6e206361637475732e6a7067, 6, 'small', 0),
(6, 'indoor', 'luck plants', 650, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x6a61646520706c616e7420676f6f64206c75636b20706c616e74732e6a7067, 6, 'small', 0),
(7, 'outdoor', 'Easy grow plants', 550, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x6561737967726f772e6a7067, 10, 'small', 0),
(8, 'outdoor', 'flowery plants', 750, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x666c6f77657279312e6a7067, 15, 'medium', 0),
(9, 'outdoor', 'thuja', 1100, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x6d6f7270616e6b68692c7468756a6120636f6d70616374612e6a7067, 7, 'large', 0),
(10, 'outdoor', 'flowery violet', 650, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x666c6f77657279322e6a706567, 10, 'medium', 0),
(11, 'outdoor', 'flowery azalea wild root', 800, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x617a616c656120666c6f77657220706c616e742077696c6420726f6f74732e6a7067, 12, 'medium', 0),
(12, 'seed', 'papaya', 70, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x7061706179612d73656564732d353030783530302e6a7067, 20, 'medium', 0),
(13, 'seed', 'spinach', 60, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x7370696e6163682d73656564732d696e2d6d792d68616e642e6a7067, 20, 'NA', 0),
(14, 'Vegetation', 'Rambutan', 750, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x72616d627574616e2e6a7067, 10, 'medium', 0),
(15, 'Vegetation', 'Star Fruit', 800, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x7374617266727569742e6a7067, 10, 'medium', 0),
(16, 'Vegetation', 'litchi Fruit', 750, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x6c69746368692d706c616e742d363030783537342e6a7067, 10, 'medium', 0),
(17, 'Vegetation', 'mango ', 700, 'his plant is mostly found in Malabar climate and it is a ann indoor plant and look like a zebra area and doesnt re', 0x6d616e676f2e6a7067, 10, 'medium', 0),
(19, 'Other', 'jamanthi', 250, 'Chrysanthemum (mum) is a plant. It gets its name from the Greek words for “gold” and “flower.” People use the flowers to make medicine. Chrysanthemum is used to treat chest pain (angina), high blood pressure, type 2 diabetes, fever, cold, headache, dizziness, and swelling.In the U.S. it has grown in popularity since its introduction in the colonial period. It is now commonly referred to as “the Queen of fall flowers”.', 0x696d6167655f7069636b6572383931363935323034313737363437343632342e6a7067, 5, 'Small', 0),
(20, 'Other', 'thymus citriodorus', 300, 'What is lemon thyme good for?\nImage result for thymus citriodorus\nLemon thyme can be used to flavour poultry, seafood, and vegetables, and will accentuate the natural flavour profiles of fish and meat dishes in particular. It can be added to marinades, stews, soups, salads, sauces, bouquet garnis and stuffing, and a few sprigs also make an attractive garnish.', 0x696d6167655f7069636b6572313538393634383635333934303033363239322e6a7067, 10, 'Medium', 0),
(21, 'Other', 'Hyssop', 400, 'Hyssop is a small perennial plant about 0.5 metre (1.5 feet) high with slim woody quadrangular stems. The dotted narrow elliptical leaves are about 2 to 3 cm (0.8 to 1.2 inches) long and grow in pairs on the stem. Long, leafy, half-whorled spikes of little flowers—usually violet-blue, pink, red, or white—blossom in summer.  hyssop, (Hyssopus officinalis), evergreen garden herb of the mint family (Lamiaceae), grown for its aromatic leaves and flowers. The plant has a sweet scent and a warm bitter', 0x696d6167655f7069636b6572373036353238363130323937303837343931392e6a7067, 12, 'Medium', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_seesion_tb`
--

CREATE TABLE `shopping_seesion_tb` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `created_at` int(11) NOT NULL,
  `modified_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_tb`
--

CREATE TABLE `student_tb` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dept` varchar(50) NOT NULL,
  `academicYear` year(4) NOT NULL,
  `degree` varchar(2) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` bigint(10) NOT NULL,
  `log_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_tb`
--

INSERT INTO `student_tb` (`id`, `name`, `dept`, `academicYear`, `degree`, `email`, `phone`, `log_id`) VALUES
(1, 'shahana', 'Physics', 2022, 'PG', 'sss@gmail.com', 9025001400, 1),
(2, 'Hiba', 'Computer Science', 2022, 'UG', 'hiba@gmail.com', 9874585200, 2),
(3, 'Sidrah', ' Maths', 2022, 'UG', 'sidrah@gmail.com', 7859800110, 3),
(4, 'Nifa', 'Computer Science', 2022, 'UG', 'Nifa@gmail.com', 7820151024, 4),
(5, 'Fida', 'Biology', 2022, 'UG', 'fida@gmail.com', 9856969610, 5),
(6, 'Meera', 'Chemistry', 2022, 'UG', 'meera@gmail.com', 9810201014, 6),
(7, 'Ayayna', 'Maths', 2023, 'PG', 'ayana@gmail.com', 9842562310, 7),
(8, 'naina', 'Food Technology', 2023, 'UG', 'nnn@gmail.com', 9065221108, 8);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `art_tb`
--
ALTER TABLE `art_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bag_tb`
--
ALTER TABLE `bag_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_tb`
--
ALTER TABLE `book_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart_item_tb`
--
ALTER TABLE `cart_item_tb`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `cloth_tb`
--
ALTER TABLE `cloth_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_tb`
--
ALTER TABLE `login_tb`
  ADD PRIMARY KEY (`log_id`);

--
-- Indexes for table `order_details_tb`
--
ALTER TABLE `order_details_tb`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_items_tb`
--
ALTER TABLE `order_items_tb`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `payment_details_tb`
--
ALTER TABLE `payment_details_tb`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `pdtcategory_tb`
--
ALTER TABLE `pdtcategory_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plant_tb`
--
ALTER TABLE `plant_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shopping_seesion_tb`
--
ALTER TABLE `shopping_seesion_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_tb`
--
ALTER TABLE `student_tb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `art_tb`
--
ALTER TABLE `art_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `bag_tb`
--
ALTER TABLE `bag_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `book_tb`
--
ALTER TABLE `book_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `cart_item_tb`
--
ALTER TABLE `cart_item_tb`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cloth_tb`
--
ALTER TABLE `cloth_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `login_tb`
--
ALTER TABLE `login_tb`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `order_details_tb`
--
ALTER TABLE `order_details_tb`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items_tb`
--
ALTER TABLE `order_items_tb`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_details_tb`
--
ALTER TABLE `payment_details_tb`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pdtcategory_tb`
--
ALTER TABLE `pdtcategory_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `plant_tb`
--
ALTER TABLE `plant_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `shopping_seesion_tb`
--
ALTER TABLE `shopping_seesion_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student_tb`
--
ALTER TABLE `student_tb`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
