-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 11, 2023 at 05:39 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uniqart`
--

-- --------------------------------------------------------

--
-- Table structure for table `artwork_table`
--

CREATE TABLE `artwork_table` (
  `art_id` bigint(10) NOT NULL,
  `category_id` bigint(10) NOT NULL,
  `art_type` varchar(25) NOT NULL,
  `art_name` varchar(25) NOT NULL,
  `price_of_art` float NOT NULL,
  `art_img` varchar(100) NOT NULL,
  `description_art` varchar(500) NOT NULL,
  `create_time` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `book_table`
--

CREATE TABLE `book_table` (
  `book_id` bigint(10) NOT NULL,
  `category_id` bigint(10) NOT NULL,
  `book_name` varchar(50) NOT NULL,
  `author_name` varchar(25) NOT NULL,
  `book_title` varchar(50) NOT NULL,
  `sub_title` varchar(50) DEFAULT NULL,
  `published_date` date DEFAULT NULL,
  `price_of_book` float DEFAULT NULL,
  `description_book` varchar(600) NOT NULL,
  `img_of_book` varchar(100) NOT NULL,
  `book_type` varchar(10) NOT NULL,
  `create_time` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `category table`
--

CREATE TABLE `category table` (
  `category_id` bigint(10) NOT NULL,
  `category_name` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `fashion_table`
--

CREATE TABLE `fashion_table` (
  `fashion_id` bigint(10) NOT NULL,
  `category_id` bigint(10) NOT NULL,
  `fashion_category` varchar(25) NOT NULL,
  `cloth_type` varchar(25) NOT NULL,
  `price_of_item` float NOT NULL,
  `size_of_item` varchar(10) NOT NULL,
  `user_type` varchar(10) NOT NULL,
  `material_fashion` varchar(10) DEFAULT NULL,
  `description_fashion` varchar(500) NOT NULL,
  `img_of_item` varchar(100) DEFAULT NULL,
  `create_time` time(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `food table`
--

CREATE TABLE `food table` (
  `food_id` bigint(20) NOT NULL,
  `category_id` bigint(10) NOT NULL,
  `food_category` varchar(25) NOT NULL,
  `food_type` varchar(25) NOT NULL,
  `food_name` varchar(25) NOT NULL,
  `price_of_food` float NOT NULL,
  `image_food` varchar(100) NOT NULL,
  `description_food` varchar(600) NOT NULL,
  `create_time` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `login_table`
--

CREATE TABLE `login_table` (
  `username` varchar(20) NOT NULL,
  `password` int(25) NOT NULL,
  `user_type` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `order_table`
--

CREATE TABLE `order_table` (
  `order_id` int(10) NOT NULL,
  `item_id` int(25) NOT NULL,
  `order_date` int(50) NOT NULL,
  `category_id` int(20) NOT NULL,
  `user_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `plant table`
--

CREATE TABLE `plant table` (
  `plant_id` bigint(10) NOT NULL,
  `category_id` bigint(10) NOT NULL,
  `plant_type` varchar(25) NOT NULL,
  `plant_name` varchar(25) NOT NULL,
  `plant_price` float NOT NULL,
  `plant_img` varchar(100) DEFAULT NULL,
  `plant_description` varchar(500) DEFAULT NULL,
  `create_time` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product_table`
--

CREATE TABLE `product_table` (
  `prdt_name` bigint(10) NOT NULL,
  `seller_id` bigint(10) DEFAULT NULL,
  `item_id` bigint(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `rental table`
--

CREATE TABLE `rental table` (
  `rental_id` bigint(10) NOT NULL,
  `rental_itemz` varchar(25) NOT NULL,
  `rental_name` varchar(20) NOT NULL,
  `rental_price` float NOT NULL,
  `size&fitof_rental` varchar(25) NOT NULL,
  `rental_img` varchar(100) NOT NULL,
  `rental_description` varchar(500) NOT NULL,
  `create_time` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `request_table`
--

CREATE TABLE `request_table` (
  `request_id` int(10) NOT NULL,
  `needy_id` int(10) NOT NULL,
  `department` varchar(25) NOT NULL,
  `description` varchar(600) NOT NULL,
  `r_date` date NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `staff_registration_table`
--

CREATE TABLE `staff_registration_table` (
  `staff_id` varchar(10) NOT NULL,
  `staff_name` varchar(30) NOT NULL,
  `department` varchar(25) NOT NULL,
  `joining_date` date NOT NULL,
  `staff_type` varchar(10) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `password` varchar(8) NOT NULL,
  `create_time` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `student_registration_table`
--

CREATE TABLE `student_registration_table` (
  `student_admno` varchar(10) NOT NULL,
  `student_name` varchar(30) NOT NULL,
  `department` varchar(25) NOT NULL,
  `academic_year` varchar(25) NOT NULL,
  `ug/pg` varchar(10) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `password` varchar(8) NOT NULL,
  `create_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artwork_table`
--
ALTER TABLE `artwork_table`
  ADD PRIMARY KEY (`art_id`);

--
-- Indexes for table `book_table`
--
ALTER TABLE `book_table`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `category table`
--
ALTER TABLE `category table`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `fashion_table`
--
ALTER TABLE `fashion_table`
  ADD PRIMARY KEY (`fashion_id`);

--
-- Indexes for table `food table`
--
ALTER TABLE `food table`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `order_table`
--
ALTER TABLE `order_table`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `plant table`
--
ALTER TABLE `plant table`
  ADD PRIMARY KEY (`plant_id`);

--
-- Indexes for table `product_table`
--
ALTER TABLE `product_table`
  ADD PRIMARY KEY (`prdt_name`);

--
-- Indexes for table `rental table`
--
ALTER TABLE `rental table`
  ADD PRIMARY KEY (`rental_id`);

--
-- Indexes for table `request_table`
--
ALTER TABLE `request_table`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `student_registration_table`
--
ALTER TABLE `student_registration_table`
  ADD PRIMARY KEY (`student_admno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artwork_table`
--
ALTER TABLE `artwork_table`
  MODIFY `art_id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `book_table`
--
ALTER TABLE `book_table`
  MODIFY `book_id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `category table`
--
ALTER TABLE `category table`
  MODIFY `category_id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fashion_table`
--
ALTER TABLE `fashion_table`
  MODIFY `fashion_id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `food table`
--
ALTER TABLE `food table`
  MODIFY `food_id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_table`
--
ALTER TABLE `order_table`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plant table`
--
ALTER TABLE `plant table`
  MODIFY `plant_id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_table`
--
ALTER TABLE `product_table`
  MODIFY `prdt_name` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `rental table`
--
ALTER TABLE `rental table`
  MODIFY `rental_id` bigint(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `request_table`
--
ALTER TABLE `request_table`
  MODIFY `request_id` int(10) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
