<?php
include 'connect.php';
if(isset($_GET['id'])){
    $o_id=$_GET['id'];
    $sql1=mysqli_query($con,"UPDATE donor_order_tb set status='accepted' where id='$o_id'");
    if($sql1){
        echo "Request accepted successfully";
        echo"<script>alert('Request accepted successfully !');</script>";

        echo "<script>window.location.href='viewRequest.php'; </script>";

        
    }else{
        echo "Something went wrong ! Could't accept request !!";
        echo"<script>alert('Something went wrong ! Failed to  accept request !');</script>";

                header('location:viewRequest.php');
    }

}
?>