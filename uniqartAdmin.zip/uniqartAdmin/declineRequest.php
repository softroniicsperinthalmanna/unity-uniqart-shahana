<?php
include 'connect.php';
if(isset($_GET['id'])){
    $o_id=$_GET['id'];
    $sql1=mysqli_query($con,"UPDATE donor_order_tb set status='declined' where id='$o_id'");
    if($sql1){
        echo " Request declined !";
        echo"<script>alert(' Request Declined !');</script>";

        echo "<script>window.location.href='viewRequest.php'; </script>";

        
    }else{
        echo "Something went wrong ! Could't decline request !!";
        echo"<script>alert('Something went wrong ! Failed to  decline request !');</script>";

                header('location:viewRequest.php');
    }

}
?>